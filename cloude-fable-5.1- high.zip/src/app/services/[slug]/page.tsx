import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { QuoteForm } from "@/components/quote-form";
import { ServiceCard } from "@/components/service-card";
import { ArrowRight, Check, Clock, Shield, Zap, accentClasses, categoryIcon } from "@/components/icons";
import { getServiceBySlug, getServices } from "@/lib/data";
import { formatINR, priceLabel } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const service = await getServiceBySlug(slug);
  if (!service) return { title: "Service not found" };
  return {
    title: `${service.name} — ${priceLabel(service)}`,
    description: service.shortDescription,
  };
}

export default async function ServiceDetailPage({ params }: Props) {
  const { slug } = await params;
  const service = await getServiceBySlug(slug);
  if (!service) notFound();

  const all = await getServices();
  const related = all.filter((s) => s.categoryId === service.categoryId && s.id !== service.id).slice(0, 3);
  const accent = accentClasses[service.category.accent] ?? accentClasses.navy;
  const Icon = categoryIcon[service.category.icon] ?? categoryIcon.sparkles;
  const options = all.map((s) => ({ slug: s.slug, name: s.name, category: s.category.name }));

  return (
    <>
      <Navbar />
      <main className="pt-32">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <nav className="flex items-center gap-2 text-sm text-slate-500">
            <Link href="/services" className="hover:text-navy-600">Services</Link>
            <span>/</span>
            <Link href={`/services?category=${service.category.slug}`} className="hover:text-navy-600">{service.category.name}</Link>
            <span>/</span>
            <span className="text-slate-900">{service.name}</span>
          </nav>

          <div className="mt-8 grid gap-12 lg:grid-cols-[1.4fr_1fr]">
            <div>
              <div className="flex items-center gap-3">
                <span className={`inline-flex h-12 w-12 items-center justify-center rounded-2xl ${accent.soft} ${accent.text}`}>
                  <Icon size={24} />
                </span>
                {service.badge && (
                  <span className="rounded-full bg-brand-red/10 px-3 py-1 text-xs font-bold uppercase tracking-wide text-brand-red">{service.badge}</span>
                )}
              </div>
              <h1 className="text-balance mt-5 text-4xl font-extrabold tracking-tight text-slate-950 sm:text-5xl">{service.name}</h1>
              <p className="mt-4 text-lg leading-relaxed text-slate-600">{service.description}</p>

              <div className="mt-8 grid gap-4 sm:grid-cols-3">
                <div className="rounded-2xl border border-slate-200 p-4">
                  <p className="text-xs font-bold uppercase tracking-wider text-slate-500">Price</p>
                  {service.originalPrice && <p className="text-sm text-slate-400 line-through">{formatINR(service.originalPrice)}</p>}
                  <p className="text-xl font-extrabold text-slate-900">{priceLabel(service)}</p>
                  {service.priceNote && <p className="mt-1 text-xs text-slate-500">{service.priceNote}</p>}
                </div>
                <div className="rounded-2xl border border-slate-200 p-4">
                  <p className="text-xs font-bold uppercase tracking-wider text-slate-500">Delivery</p>
                  <p className="flex items-center gap-2 text-xl font-extrabold text-slate-900"><Clock size={20} className="text-navy-600" /> {service.deliveryDays} days</p>
                  <p className="mt-1 text-xs text-slate-500">after receiving content</p>
                </div>
                <div className="rounded-2xl border border-slate-200 p-4">
                  <p className="text-xs font-bold uppercase tracking-wider text-slate-500">Support</p>
                  <p className="flex items-center gap-2 text-xl font-extrabold text-slate-900"><Shield size={20} className="text-navy-600" /> Included</p>
                  <p className="mt-1 text-xs text-slate-500">post-launch assistance</p>
                </div>
              </div>

              <h2 className="mt-12 text-2xl font-extrabold text-slate-950">What&apos;s included</h2>
              <ul className="mt-5 grid gap-3 sm:grid-cols-2">
                {service.features.map((f) => (
                  <li key={f} className="flex items-start gap-3 rounded-2xl bg-slate-50 p-4 text-sm font-medium text-slate-800">
                    <span className="mt-0.5 inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-brand-green text-white"><Check size={12} /></span>
                    {f}
                  </li>
                ))}
              </ul>

              <div className="mt-12 rounded-3xl bg-navy-600 p-8 text-white">
                <div className="flex items-start gap-4">
                  <Zap className="mt-1 shrink-0 text-brand-yellow" size={24} />
                  <div>
                    <h3 className="text-xl font-extrabold">How we work</h3>
                    <ol className="mt-3 space-y-2 text-sm text-navy-100">
                      <li>1. You share your requirement &amp; we confirm the scope and price.</li>
                      <li>2. 50% advance to start — we share live previews as we build.</li>
                      <li>3. Review, revise, approve. Balance 50% on delivery.</li>
                      <li>4. Launch, handover and free support period begins.</li>
                    </ol>
                  </div>
                </div>
              </div>
            </div>

            <aside className="lg:sticky lg:top-28 lg:self-start">
              <div className="rounded-[32px] border border-slate-200 bg-white p-6 shadow-[0_24px_60px_-24px_rgba(45,46,143,0.3)] sm:p-8">
                <h2 className="text-xl font-extrabold text-slate-950">Get started with {service.name}</h2>
                <p className="mt-1 text-sm text-slate-600">Fill this in and we&apos;ll confirm pricing &amp; timeline within 24 hours.</p>
                <div className="mt-6">
                  <QuoteForm services={options} defaultService={service.slug} source={`service:${service.slug}`} compact />
                </div>
              </div>
            </aside>
          </div>

          {related.length > 0 && (
            <section className="mt-24">
              <div className="flex items-end justify-between">
                <h2 className="text-2xl font-extrabold text-slate-950 sm:text-3xl">More in {service.category.name}</h2>
                <Link href={`/services?category=${service.category.slug}`} className="inline-flex items-center gap-1.5 text-sm font-bold text-navy-600">
                  View all <ArrowRight size={16} />
                </Link>
              </div>
              <div className="mt-8 grid gap-6 md:grid-cols-3">
                {related.map((s) => (
                  <ServiceCard key={s.id} service={s} />
                ))}
              </div>
            </section>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}
