import Link from "next/link";
import type { Metadata } from "next";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { ServiceCard } from "@/components/service-card";
import { Reveal } from "@/components/reveal";
import { ArrowRight } from "@/components/icons";
import { getCategories, getServices } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Services & Pricing",
  description: "Website design, CRM & business software, digital marketing and brand identity services with transparent pricing in INR.",
};

export default async function ServicesPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>;
}) {
  const { category } = await searchParams;
  const [cats, items] = await Promise.all([getCategories(), getServices(category)]);
  const active = cats.find((c) => c.slug === category);

  return (
    <>
      <Navbar />
      <main className="pt-32">
        <section className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="max-w-3xl">
            <p className="text-sm font-bold uppercase tracking-[0.2em] text-navy-600">Services &amp; pricing</p>
            <h1 className="text-balance mt-3 text-4xl font-extrabold tracking-tight text-slate-950 sm:text-6xl">
              {active ? active.name : "Everything your business needs online"}
            </h1>
            <p className="mt-4 text-lg text-slate-600">
              {active ? active.description : "Pick a service, see the price upfront, and get started in minutes. Custom requirements? We quote within 24 hours."}
            </p>
          </div>

          <div className="mt-10 flex flex-wrap gap-2">
            <Link
              href="/services"
              className={`rounded-full border px-4 py-2 text-sm font-semibold transition ${!category ? "border-navy-600 bg-navy-600 text-white" : "border-slate-300 bg-white text-slate-700 hover:border-navy-300"}`}
            >
              All ({items.length})
            </Link>
            {cats.map((c) => (
              <Link
                key={c.id}
                href={`/services?category=${c.slug}`}
                className={`rounded-full border px-4 py-2 text-sm font-semibold transition ${category === c.slug ? "border-navy-600 bg-navy-600 text-white" : "border-slate-300 bg-white text-slate-700 hover:border-navy-300"}`}
              >
                {c.name}
              </Link>
            ))}
          </div>

          {items.length === 0 ? (
            <div className="mt-16 rounded-3xl border border-dashed border-slate-300 p-12 text-center text-slate-500">
              No services found in this category yet.
            </div>
          ) : (
            <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {items.map((s, i) => (
                <Reveal key={s.id} delay={(i % 3) * 60}>
                  <ServiceCard service={s} />
                </Reveal>
              ))}
            </div>
          )}

          <div className="mt-16 rounded-[32px] border border-slate-200 bg-slate-50 p-8 sm:flex sm:items-center sm:justify-between sm:p-10">
            <div>
              <h2 className="text-2xl font-extrabold text-slate-950">Need something custom?</h2>
              <p className="mt-2 text-slate-600">Describe your idea — we&apos;ll scope it and send a fixed-price proposal.</p>
            </div>
            <Link href="/get-started" className="mt-6 inline-flex h-12 items-center gap-2 rounded-full bg-navy-600 px-6 text-sm font-bold text-white transition hover:bg-navy-700 sm:mt-0">
              Get a free quote <ArrowRight size={16} />
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
