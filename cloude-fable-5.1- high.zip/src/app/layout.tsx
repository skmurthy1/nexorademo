import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://www.nexorasoftwares.com"),
  title: {
    default: "Nexora Softwares — Websites, Software & Digital Marketing | You GET What You EXPECT",
    template: "%s | Nexora Softwares",
  },
  description:
    "Nexora Softwares builds modern websites, CRM & business software, brand identity and digital marketing for growing businesses in India. Transparent pricing, fast delivery.",
  keywords: [
    "website design India",
    "CRM software small business",
    "digital marketing Hyderabad",
    "logo design",
    "e-commerce website",
    "Nexora Softwares",
  ],
  openGraph: {
    type: "website",
    siteName: "Nexora Softwares",
    title: "Nexora Softwares — You GET What You EXPECT",
    description: "Modern websites, business software and digital marketing — delivered fast, priced honestly.",
    url: "https://www.nexorasoftwares.com",
  },
  icons: { icon: "/icon.svg" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen bg-white font-sans text-slate-900 antialiased selection:bg-navy-100 selection:text-navy-900">
        {children}
      </body>
    </html>
  );
}
