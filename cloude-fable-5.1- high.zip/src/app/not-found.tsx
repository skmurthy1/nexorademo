import Link from "next/link";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { LogoMark } from "@/components/logo";
import { ArrowRight } from "@/components/icons";

export default function NotFound() {
  return (
    <>
      <Navbar />
      <main className="flex min-h-[70vh] flex-col items-center justify-center px-5 pt-24 text-center">
        <LogoMark size={72} />
        <p className="mt-6 text-sm font-bold uppercase tracking-[0.2em] text-navy-600">404</p>
        <h1 className="mt-2 text-4xl font-extrabold tracking-tight text-slate-950">Page not found</h1>
        <p className="mt-3 max-w-md text-slate-600">The page you&apos;re looking for doesn&apos;t exist or has moved.</p>
        <Link href="/" className="mt-8 inline-flex h-12 items-center gap-2 rounded-full bg-navy-600 px-6 text-sm font-bold text-white hover:bg-navy-700">
          Back to home <ArrowRight size={16} />
        </Link>
      </main>
      <Footer />
    </>
  );
}
