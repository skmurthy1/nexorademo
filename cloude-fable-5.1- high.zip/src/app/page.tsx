import Link from "next/link";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { HeroPrompt } from "@/components/hero-prompt";
import { Marquee } from "@/components/marquee";
import { Reveal } from "@/components/reveal";
import { ServiceCard } from "@/components/service-card";
import { FaqAccordion } from "@/components/faq";
import { ArrowRight, Check, Star, Zap, Shield, Sparkles, accentClasses, categoryIcon } from "@/components/icons";
import { ChatBuildMockup, DashboardMockup, PipelineMockup, RolesMockup, SearchMockup } from "@/components/home/mockups";
import { getCategories, getFaqs, getPopularServices, getTestimonials } from "@/lib/data";

export const dynamic = "force-dynamic";

const trusted = ["RK Interiors", "Bright Minds Academy", "Reddy Pharma", "Urban Bloom", "Irfan Steel", "Green Valley School", "VS Legal", "Spice Route"];

const builtIn: string[][] = [
  ["Custom design", "Mobile-first", "SEO", "Fast hosting", "Free SSL", "Custom domain", "Analytics", "Contact forms", "WhatsApp chat", "Google Maps"],
  ["Payments (UPI / Cards)", "GST invoices", "Order tracking", "Inventory", "Coupons", "Shipping rules", "Customer accounts", "Email & SMS alerts", "Admin dashboard"],
  ["CRM pipeline", "Task reminders", "Roles & permissions", "Reports", "Excel import", "Daily backups", "Secure login", "API integrations", "Automation"],
  ["Logo & brand kit", "Visiting cards", "Brochures", "Company profile", "Google Business", "Instagram setup", "Promo videos", "Festival posts", "Reviews"],
];

const steps = [
  { title: "Tell us what you need", body: "Describe your business and goals in plain words — a website, a CRM, a brand refresh. No technical jargon required." },
  { title: "We design & build it", body: "Our team builds on modern, secure stacks and shares live previews so you see progress every step of the way." },
  { title: "Launch and grow", body: "Go live on your domain in days, not months. We stay with you after launch with support and growth plans." },
];

export default async function HomePage() {
  const [popular, testimonialsList, faqList, cats] = await Promise.all([
    getPopularServices(6),
    getTestimonials(),
    getFaqs(),
    getCategories(),
  ]);
  const half = Math.ceil(testimonialsList.length / 2);
  const rowA = testimonialsList.slice(0, half);
  const rowB = testimonialsList.slice(half);

  return (
    <>
      <Navbar />
      <main>
        {/* HERO */}
        <section className="relative overflow-hidden pt-36 pb-20 sm:pt-44">
          <div className="bg-grid pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_75%)]" />
          <div className="pointer-events-none absolute -top-40 left-1/2 h-[520px] w-[900px] -translate-x-1/2 rounded-full bg-[radial-gradient(closest-side,rgba(30,111,219,0.16),transparent)] blur-2xl" />
          <div className="pointer-events-none absolute top-10 right-[-10%] h-72 w-72 rounded-full bg-[radial-gradient(closest-side,rgba(230,57,70,0.14),transparent)] blur-2xl" />
          <div className="pointer-events-none absolute top-40 left-[-8%] h-72 w-72 rounded-full bg-[radial-gradient(closest-side,rgba(249,200,14,0.18),transparent)] blur-2xl" />

          <div className="relative mx-auto max-w-5xl px-5 text-center sm:px-8">
            <div className="animate-fade-up inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white/80 px-4 py-1.5 text-xs font-semibold text-slate-700 shadow-sm backdrop-blur">
              <span className="inline-flex h-2 w-2 rounded-full bg-brand-green" />
              Now building on Next.js 16 · 2026 stack
            </div>
            <h1 className="animate-fade-up text-balance mt-6 text-[clamp(2.4rem,6.2vw,4.6rem)] font-extrabold leading-[1.02] tracking-tight text-slate-950 [animation-delay:80ms]">
              Websites, software &amp; marketing for your business — <span className="gradient-text">without the agency price tag</span>
            </h1>
            <p className="animate-fade-up mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-slate-600 [animation-delay:160ms]">
              Nexora Softwares designs and builds modern websites, CRM &amp; business software, brand identity and
              digital marketing — delivered in days, with transparent pricing. <span className="font-semibold text-brand-red">You GET what you EXPECT.</span>
            </p>
            <div className="animate-fade-up [animation-delay:240ms]">
              <HeroPrompt />
            </div>
            <div className="animate-fade-up mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-slate-500 [animation-delay:320ms]">
              <span className="inline-flex items-center gap-1.5"><Check size={16} className="text-brand-green" /> Free quote in 24 hours</span>
              <span className="inline-flex items-center gap-1.5"><Check size={16} className="text-brand-green" /> Starting at ₹500</span>
              <span className="inline-flex items-center gap-1.5"><Check size={16} className="text-brand-green" /> You own everything</span>
            </div>
          </div>

          {/* Trusted by */}
          <div className="relative mx-auto mt-16 max-w-6xl px-5 sm:px-8">
            <p className="text-center text-xs font-bold uppercase tracking-[0.2em] text-slate-400">Trusted by 500+ businesses across India</p>
            <div className="mask-fade-x mt-6">
              <Marquee duration="35s" gap="3rem">
                {trusted.map((t) => (
                  <span key={t} className="whitespace-nowrap text-lg font-extrabold tracking-tight text-slate-300 sm:text-xl">
                    {t}
                  </span>
                ))}
              </Marquee>
            </div>
          </div>
        </section>

        {/* HOW IT WORKS */}
        <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8">
          <Reveal className="mx-auto max-w-3xl text-center">
            <p className="text-sm font-bold uppercase tracking-[0.2em] text-navy-600">How it works</p>
            <h2 className="text-balance mt-3 text-3xl font-extrabold tracking-tight text-slate-950 sm:text-5xl">From idea to launched in days</h2>
            <p className="mt-4 text-lg text-slate-600">Describe what you want. We build it — and show you progress in real time.</p>
          </Reveal>
          <div className="mt-14 grid items-center gap-12 lg:grid-cols-2">
            <Reveal>
              <ChatBuildMockup />
            </Reveal>
            <ol className="space-y-6">
              {steps.map((s, i) => (
                <Reveal key={s.title} delay={i * 100} as="li" className="flex gap-5 rounded-3xl border border-slate-200 bg-white p-6 transition hover:border-navy-200 hover:shadow-[0_20px_50px_-24px_rgba(45,46,143,0.35)]">
                  <span className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-navy-600 text-base font-extrabold text-white">
                    {i + 1}
                  </span>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900">{s.title}</h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-slate-600">{s.body}</p>
                  </div>
                </Reveal>
              ))}
            </ol>
          </div>
        </section>

        {/* BUILT-IN MARQUEE */}
        <section className="overflow-hidden border-y border-slate-200 bg-slate-50 py-20">
          <Reveal className="mx-auto max-w-3xl px-5 text-center sm:px-8">
            <p className="text-sm font-bold uppercase tracking-[0.2em] text-navy-600">Everything included</p>
            <h2 className="text-balance mt-3 text-3xl font-extrabold tracking-tight text-slate-950 sm:text-5xl">Everything you need is built in</h2>
            <p className="mt-4 text-lg text-slate-600">
              Design, hosting, domain, SEO, payments, WhatsApp, CRM, branding — and 100s of other features, available with every project.
            </p>
          </Reveal>
          <div className="mask-fade-x mt-12 space-y-4">
            {builtIn.map((row, i) => (
              <Marquee key={i} reverse={i % 2 === 1} duration={`${44 + i * 6}s`} gap="1rem">
                {row.map((item) => (
                  <span
                    key={item}
                    className="inline-flex items-center gap-2 whitespace-nowrap rounded-full border border-slate-200 bg-white px-5 py-2.5 text-sm font-semibold text-slate-700 shadow-sm"
                  >
                    <span className={`h-2 w-2 rounded-full ${["bg-brand-red", "bg-brand-yellow", "bg-brand-green", "bg-brand-blue"][i]}`} />
                    {item}
                  </span>
                ))}
              </Marquee>
            ))}
          </div>
          <p className="mt-10 text-center text-sm font-semibold text-slate-500">+ 1,000s of integrations: Razorpay, WhatsApp Business, Google Maps, Zoho, Tally &amp; more</p>
        </section>

        {/* BENTO FEATURES */}
        <section className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
          <Reveal className="mx-auto max-w-3xl text-center">
            <p className="text-sm font-bold uppercase tracking-[0.2em] text-navy-600">What we build</p>
            <h2 className="text-balance mt-3 text-3xl font-extrabold tracking-tight text-slate-950 sm:text-5xl">One team for your entire online business</h2>
          </Reveal>
          <div className="mt-14 grid gap-6 lg:grid-cols-3">
            <Reveal className="rounded-[32px] border border-slate-200 bg-white p-8 lg:col-span-2 lg:p-10">
              <div className="grid items-center gap-8 lg:grid-cols-2">
                <div>
                  <span className="inline-flex items-center gap-2 rounded-full bg-blue-50 px-3 py-1 text-xs font-bold text-brand-blue"><Zap size={14} /> Websites</span>
                  <h3 className="mt-4 text-2xl font-extrabold text-slate-950 sm:text-3xl">Launch on your domain in a click</h3>
                  <p className="mt-3 text-slate-600">
                    Blazing-fast, mobile-first websites with SEO, analytics and enquiry forms built in. Business sites from ₹5,000, e-commerce from ₹20,000.
                  </p>
                  <Link href="/services?category=website-design" className="mt-5 inline-flex items-center gap-1.5 text-sm font-bold text-navy-600 hover:gap-2.5 transition-all">
                    Explore website designs <ArrowRight size={16} />
                  </Link>
                </div>
                <DashboardMockup />
              </div>
            </Reveal>
            <Reveal delay={100} className="rounded-[32px] border border-slate-200 bg-navy-950 p-8 text-white lg:p-10">
              <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-bold text-white"><Shield size={14} /> Software &amp; CRM</span>
              <h3 className="mt-4 text-2xl font-extrabold sm:text-3xl">Run your business from one place</h3>
              <p className="mt-3 text-navy-200">Leads, tasks, invoices and reports with roles for your whole team.</p>
              <div className="mt-6 text-slate-900">
                <PipelineMockup />
              </div>
              <div className="mt-6 flex items-end justify-between">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-navy-300">Launch offer</p>
                  <p className="text-3xl font-extrabold">₹2,000 <span className="text-base font-semibold text-navy-300 line-through">₹25,000</span></p>
                </div>
                <Link href="/services/workflow-crm-software" className="inline-flex h-10 items-center gap-1.5 rounded-full bg-white px-4 text-sm font-bold text-navy-700">
                  View CRM <ArrowRight size={16} />
                </Link>
              </div>
            </Reveal>
            <Reveal delay={150} className="rounded-[32px] border border-slate-200 bg-white p-8 lg:p-10">
              <span className="inline-flex items-center gap-2 rounded-full bg-red-50 px-3 py-1 text-xs font-bold text-brand-red"><Sparkles size={14} /> Digital marketing</span>
              <h3 className="mt-4 text-2xl font-extrabold text-slate-950">Get found by local customers</h3>
              <p className="mt-3 text-slate-600">Google Business, social media and promo videos that bring real calls.</p>
              <div className="mt-6"><SearchMockup /></div>
            </Reveal>
            <Reveal delay={200} className="rounded-[32px] border border-slate-200 bg-white p-8 lg:p-10">
              <span className="inline-flex items-center gap-2 rounded-full bg-amber-50 px-3 py-1 text-xs font-bold text-amber-600"><Star size={14} /> Brand identity</span>
              <h3 className="mt-4 text-2xl font-extrabold text-slate-950">Look as good as you are</h3>
              <p className="mt-3 text-slate-600">Logo, visiting cards, brochures and company profiles — one consistent identity.</p>
              <div className="mt-6 grid grid-cols-4 gap-2">
                {["#2D2E8F", "#E63946", "#F9C80E", "#2BB673"].map((c) => (
                  <div key={c} className="aspect-square rounded-2xl shadow-inner" style={{ background: c }} />
                ))}
              </div>
              <div className="mt-3 rounded-2xl border border-slate-200 p-3">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Brand kit</p>
                <p className="text-sm font-extrabold text-slate-900">Logo · Fonts · Colours · Cards · Brochure</p>
              </div>
            </Reveal>
            <Reveal delay={250} className="rounded-[32px] border border-slate-200 bg-gradient-to-br from-slate-50 to-white p-8 lg:p-10">
              <span className="inline-flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-600"><Shield size={14} /> Secure &amp; yours</span>
              <h3 className="mt-4 text-2xl font-extrabold text-slate-950">Govern with confidence</h3>
              <p className="mt-3 text-slate-600">Role-based access, daily backups and full ownership of code, domain and data.</p>
              <div className="mt-6"><RolesMockup /></div>
            </Reveal>
          </div>
        </section>

        {/* CATEGORIES + POPULAR SERVICES */}
        <section className="border-t border-slate-200 bg-slate-50 py-24">
          <div className="mx-auto max-w-7xl px-5 sm:px-8">
            <Reveal className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
              <div className="max-w-2xl">
                <p className="text-sm font-bold uppercase tracking-[0.2em] text-navy-600">Services &amp; pricing</p>
                <h2 className="text-balance mt-3 text-3xl font-extrabold tracking-tight text-slate-950 sm:text-5xl">Transparent prices. No surprises.</h2>
              </div>
              <Link href="/services" className="inline-flex items-center gap-2 rounded-full border border-slate-300 bg-white px-5 py-2.5 text-sm font-semibold text-slate-800 transition hover:border-navy-300 hover:text-navy-700">
                View all {cats.length} categories <ArrowRight size={16} />
              </Link>
            </Reveal>
            <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {cats.map((c, i) => {
                const accent = accentClasses[c.accent] ?? accentClasses.navy;
                const Icon = categoryIcon[c.icon] ?? categoryIcon.sparkles;
                return (
                  <Reveal key={c.id} delay={i * 60}>
                    <Link href={`/services?category=${c.slug}`} className="group flex h-full items-center gap-4 rounded-3xl border border-slate-200 bg-white p-5 transition hover:-translate-y-0.5 hover:border-navy-200 hover:shadow-lg">
                      <span className={`inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl ${accent.bg} text-white`}>
                        <Icon size={22} />
                      </span>
                      <div className="min-w-0">
                        <p className="font-bold text-slate-900">{c.name}</p>
                        <p className="truncate text-xs text-slate-500">{c.tagline}</p>
                      </div>
                      <ArrowRight size={18} className="ml-auto text-slate-300 transition group-hover:translate-x-1 group-hover:text-navy-600" />
                    </Link>
                  </Reveal>
                );
              })}
            </div>
            <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {popular.map((s, i) => (
                <Reveal key={s.id} delay={(i % 3) * 80}>
                  <ServiceCard service={s} />
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* STATS */}
        <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8">
          <div className="grid gap-6 rounded-[32px] bg-navy-600 p-8 text-white sm:grid-cols-2 lg:grid-cols-4 lg:p-12">
            {[
              ["500+", "Projects delivered"],
              ["10+", "Years of experience"],
              ["4.9★", "Average client rating"],
              ["24h", "Quote turnaround"],
            ].map(([v, l]) => (
              <div key={l} className="border-white/10 sm:border-l sm:pl-6 first:border-0 first:pl-0">
                <p className="text-4xl font-extrabold tracking-tight sm:text-5xl">{v}</p>
                <p className="mt-1 text-sm font-medium text-navy-200">{l}</p>
              </div>
            ))}
          </div>
        </section>

        {/* TESTIMONIALS */}
        <section className="overflow-hidden py-16">
          <Reveal className="mx-auto max-w-3xl px-5 text-center sm:px-8">
            <p className="text-sm font-bold uppercase tracking-[0.2em] text-navy-600">Loved by business owners</p>
            <h2 className="text-balance mt-3 text-3xl font-extrabold tracking-tight text-slate-950 sm:text-5xl">Never built software before? Neither had our customers.</h2>
          </Reveal>
          <div className="mask-fade-x mt-12 space-y-5">
            {[rowA, rowB].map((row, i) => (
              <Marquee key={i} reverse={i === 1} duration="70s" gap="1.25rem">
                {row.map((t) => (
                  <figure key={t.id} className="flex w-[360px] shrink-0 flex-col justify-between rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
                    <div>
                      <div className="flex gap-0.5 text-amber-400">
                        {Array.from({ length: t.rating }).map((_, k) => (
                          <Star key={k} size={14} />
                        ))}
                      </div>
                      <blockquote className="mt-3 text-[15px] leading-relaxed text-slate-700">“{t.quote}”</blockquote>
                    </div>
                    <figcaption className="mt-5 flex items-center gap-3">
                      <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-navy-600 text-sm font-bold text-white">{t.name[0]}</span>
                      <div>
                        <p className="text-sm font-bold text-slate-900">{t.name}</p>
                        <p className="text-xs text-slate-500">{t.role}, {t.company}</p>
                      </div>
                    </figcaption>
                  </figure>
                ))}
              </Marquee>
            ))}
          </div>
        </section>

        {/* FAQ */}
        <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8">
          <div className="grid gap-10 lg:grid-cols-[1fr_1.6fr]">
            <Reveal>
              <p className="text-sm font-bold uppercase tracking-[0.2em] text-navy-600">FAQ</p>
              <h2 className="text-balance mt-3 text-3xl font-extrabold tracking-tight text-slate-950 sm:text-4xl">Frequently asked questions</h2>
              <p className="mt-4 text-slate-600">Still have questions? We&apos;re happy to help.</p>
              <Link href="/contact" className="mt-5 inline-flex items-center gap-2 rounded-full bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-slate-800">
                Contact us <ArrowRight size={16} />
              </Link>
            </Reveal>
            <Reveal delay={100}>
              <FaqAccordion items={faqList} />
            </Reveal>
          </div>
        </section>

        {/* CTA */}
        <section className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="relative overflow-hidden rounded-[40px] bg-navy-950 px-6 py-20 text-center text-white sm:px-12">
            <div className="bg-dots pointer-events-none absolute inset-0 opacity-30 [mask-image:radial-gradient(ellipse_at_center,black,transparent_70%)]" />
            <div className="pointer-events-none absolute -bottom-32 left-1/2 h-72 w-[700px] -translate-x-1/2 rounded-full bg-[radial-gradient(closest-side,rgba(30,111,219,0.5),transparent)] blur-3xl" />
            <div className="relative">
              <h2 className="text-balance text-3xl font-extrabold tracking-tight sm:text-5xl">Start your project today</h2>
              <p className="mx-auto mt-4 max-w-xl text-lg text-navy-200">No commitment. Describe your idea and get a detailed, fixed-price quote within one working day.</p>
              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <Link href="/get-started" className="inline-flex h-12 items-center gap-2 rounded-full bg-white px-6 text-sm font-bold text-navy-700 transition hover:bg-navy-50">
                  Get a free quote <ArrowRight size={16} />
                </Link>
                <Link href="/services" className="inline-flex h-12 items-center gap-2 rounded-full border border-white/20 px-6 text-sm font-bold text-white transition hover:bg-white/10">
                  Browse services
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
