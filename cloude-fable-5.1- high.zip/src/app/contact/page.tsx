import type { Metadata } from "next";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { QuoteForm } from "@/components/quote-form";
import { Mail, MapPin, Phone, Whatsapp } from "@/components/icons";
import { getServices } from "@/lib/data";
import { COMPANY } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Contact Us",
  description: "Get in touch with Nexora Softwares — call, WhatsApp or send a message. We reply within one working day.",
};

export default async function ContactPage() {
  const all = await getServices();
  const options = all.map((s) => ({ slug: s.slug, name: s.name, category: s.category.name }));
  const cards = [
    { icon: Phone, label: "Call us", value: COMPANY.phone, href: `tel:${COMPANY.phone.replace(/\s/g, "")}` },
    { icon: Whatsapp, label: "WhatsApp", value: "Chat instantly", href: `https://wa.me/${COMPANY.whatsapp}` },
    { icon: Mail, label: "Email", value: COMPANY.email, href: `mailto:${COMPANY.email}` },
    { icon: MapPin, label: "Office", value: COMPANY.address, href: "#" },
  ];

  return (
    <>
      <Navbar />
      <main className="pt-32">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="max-w-3xl">
            <p className="text-sm font-bold uppercase tracking-[0.2em] text-navy-600">Contact</p>
            <h1 className="text-balance mt-3 text-4xl font-extrabold tracking-tight text-slate-950 sm:text-6xl">Let&apos;s talk about your business</h1>
            <p className="mt-4 text-lg text-slate-600">Questions, custom requirements or just want advice? We&apos;re happy to help — no sales pressure.</p>
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {cards.map((c) => (
              <a key={c.label} href={c.href} className="group rounded-3xl border border-slate-200 bg-white p-6 transition hover:-translate-y-0.5 hover:border-navy-200 hover:shadow-lg">
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-navy-50 text-navy-600 transition group-hover:bg-navy-600 group-hover:text-white">
                  <c.icon size={20} />
                </span>
                <p className="mt-4 text-xs font-bold uppercase tracking-wider text-slate-500">{c.label}</p>
                <p className="mt-1 font-semibold text-slate-900">{c.value}</p>
              </a>
            ))}
          </div>
          <div className="mt-12 grid gap-10 lg:grid-cols-[1fr_1.4fr]">
            <div className="rounded-[32px] bg-navy-950 p-8 text-white sm:p-10">
              <h2 className="text-2xl font-extrabold">Working hours</h2>
              <ul className="mt-5 space-y-3 text-sm text-navy-100">
                <li className="flex justify-between border-b border-white/10 pb-3"><span>Monday – Friday</span><span className="font-semibold text-white">10:00 – 19:00</span></li>
                <li className="flex justify-between border-b border-white/10 pb-3"><span>Saturday</span><span className="font-semibold text-white">10:00 – 16:00</span></li>
                <li className="flex justify-between"><span>Sunday</span><span className="font-semibold text-white">Closed</span></li>
              </ul>
              <p className="mt-8 text-sm text-navy-200">Existing client with an urgent issue? WhatsApp us anytime — support tickets are monitored 24/7.</p>
            </div>
            <div className="rounded-[32px] border border-slate-200 bg-white p-6 sm:p-10">
              <h2 className="text-2xl font-extrabold text-slate-950">Send a message</h2>
              <div className="mt-6">
                <QuoteForm services={options} source="contact" />
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
