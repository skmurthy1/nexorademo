import type { Metadata } from "next";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { QuoteForm } from "@/components/quote-form";
import { Check } from "@/components/icons";
import { getServices } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Get a Free Quote",
  description: "Describe your project and receive a fixed-price proposal from Nexora Softwares within one working day.",
};

const perks = [
  "Fixed-price proposal — no hourly surprises",
  "Reply within one working day",
  "Live previews while we build",
  "You own code, domain and data",
  "Free post-launch support included",
];

export default async function GetStartedPage({
  searchParams,
}: {
  searchParams: Promise<{ brief?: string; service?: string }>;
}) {
  const { brief, service } = await searchParams;
  const all = await getServices();
  const options = all.map((s) => ({ slug: s.slug, name: s.name, category: s.category.name }));

  return (
    <>
      <Navbar />
      <main className="relative pt-32">
        <div className="bg-grid pointer-events-none absolute inset-x-0 top-0 h-[520px] [mask-image:linear-gradient(to_bottom,black,transparent)]" />
        <div className="relative mx-auto grid max-w-7xl gap-12 px-5 sm:px-8 lg:grid-cols-[1fr_1.3fr]">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.2em] text-navy-600">Free quote</p>
            <h1 className="text-balance mt-3 text-4xl font-extrabold tracking-tight text-slate-950 sm:text-5xl">Tell us what you want to build</h1>
            <p className="mt-4 text-lg text-slate-600">
              A website, software, branding or marketing — describe it in your own words. We&apos;ll come back with a clear scope, price and timeline.
            </p>
            <ul className="mt-8 space-y-3">
              {perks.map((p) => (
                <li key={p} className="flex items-center gap-3 text-sm font-medium text-slate-800">
                  <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-brand-green text-white"><Check size={14} /></span>
                  {p}
                </li>
              ))}
            </ul>
            <div className="mt-10 rounded-3xl border border-slate-200 bg-white p-6">
              <p className="text-sm font-bold text-slate-900">Prefer to talk?</p>
              <p className="mt-1 text-sm text-slate-600">Call or WhatsApp us on <span className="font-semibold text-navy-700">+91 98765 43210</span>, Mon–Sat 10am–7pm IST.</p>
            </div>
          </div>
          <div className="rounded-[32px] border border-slate-200 bg-white p-6 shadow-[0_30px_80px_-30px_rgba(45,46,143,0.35)] sm:p-10">
            <QuoteForm services={options} defaultBrief={brief} defaultService={service} source="get-started" />
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
