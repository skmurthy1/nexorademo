"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { LogoMark } from "@/components/logo";
import { ArrowRight } from "@/components/icons";

export function AdminLogin() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password }),
    });
    setLoading(false);
    if (!res.ok) {
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      setError(data.error ?? "Login failed");
      return;
    }
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} className="w-full max-w-sm rounded-[32px] border border-slate-200 bg-white p-8 shadow-[0_30px_80px_-30px_rgba(45,46,143,0.35)]">
      <div className="flex justify-center"><LogoMark size={56} /></div>
      <h1 className="mt-5 text-center text-2xl font-extrabold text-slate-950">Client / Admin login</h1>
      <p className="mt-1 text-center text-sm text-slate-600">Enter the admin password to view enquiries.</p>
      <label className="mt-6 block text-xs font-bold uppercase tracking-wider text-slate-500">Password</label>
      <input
        type="password"
        required
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="mt-1.5 h-12 w-full rounded-2xl border border-slate-300 px-4 text-sm outline-none focus:border-navy-500 focus:ring-4 focus:ring-navy-100"
        placeholder="••••••••"
      />
      {error && <p className="mt-2 text-sm font-medium text-brand-red">{error}</p>}
      <button
        type="submit"
        disabled={loading}
        className="mt-5 inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-navy-600 text-sm font-bold text-white transition hover:bg-navy-700 disabled:opacity-60"
      >
        {loading ? "Signing in…" : "Sign in"} <ArrowRight size={16} />
      </button>
      <p className="mt-4 text-center text-xs text-slate-400">Default password: <code className="rounded bg-slate-100 px-1.5 py-0.5">nexora2024</code> — set <code>ADMIN_PASSWORD</code> to change.</p>
    </form>
  );
}
