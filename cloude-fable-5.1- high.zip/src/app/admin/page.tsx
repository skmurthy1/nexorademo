import type { Metadata } from "next";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { isAdmin } from "@/lib/admin-auth";
import { getLeads, getLeadStats, getServices } from "@/lib/data";
import { AdminLogin } from "./admin-login";
import { LeadsTable } from "./leads-table";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Admin — Leads",
  robots: { index: false, follow: false },
};

export default async function AdminPage() {
  const authed = await isAdmin();

  if (!authed) {
    return (
      <>
        <Navbar />
        <main className="flex min-h-screen items-center justify-center px-5 pt-24">
          <AdminLogin />
        </main>
      </>
    );
  }

  const [leadRows, stats, services] = await Promise.all([getLeads(), getLeadStats(), getServices()]);
  const serviceNames = Object.fromEntries(services.map((s) => [s.slug, s.name]));

  return (
    <>
      <Navbar />
      <main className="pt-32">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div>
              <p className="text-sm font-bold uppercase tracking-[0.2em] text-navy-600">Admin</p>
              <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-slate-950 sm:text-4xl">Leads &amp; enquiries</h1>
            </div>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-4">
            {[
              ["Total leads", stats.total, "bg-navy-600"],
              ["New", stats.newCount, "bg-brand-blue"],
              ["Contacted", stats.contacted, "bg-brand-yellow"],
              ["Won", stats.won, "bg-brand-green"],
            ].map(([label, value, color]) => (
              <div key={label as string} className="rounded-3xl border border-slate-200 bg-white p-5">
                <div className="flex items-center gap-2">
                  <span className={`h-2.5 w-2.5 rounded-full ${color}`} />
                  <p className="text-xs font-bold uppercase tracking-wider text-slate-500">{label}</p>
                </div>
                <p className="mt-2 text-3xl font-extrabold text-slate-950">{value}</p>
              </div>
            ))}
          </div>
          <div className="mt-8">
            <LeadsTable initialLeads={leadRows} serviceNames={serviceNames} />
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
