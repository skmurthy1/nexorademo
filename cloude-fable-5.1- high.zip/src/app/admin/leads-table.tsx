"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import type { Lead } from "@/db/schema";
import { LEAD_STATUSES, type LeadStatus } from "@/lib/format";

const statusStyles: Record<string, string> = {
  new: "bg-blue-50 text-brand-blue border-blue-200",
  contacted: "bg-amber-50 text-amber-700 border-amber-200",
  quoted: "bg-navy-50 text-navy-700 border-navy-200",
  won: "bg-emerald-50 text-emerald-700 border-emerald-200",
  lost: "bg-slate-100 text-slate-600 border-slate-200",
};

export function LeadsTable({ initialLeads, serviceNames }: { initialLeads: Lead[]; serviceNames: Record<string, string> }) {
  const router = useRouter();
  const [leads, setLeads] = useState(initialLeads);
  const [filter, setFilter] = useState<"all" | LeadStatus>("all");
  const [query, setQuery] = useState("");
  const [expanded, setExpanded] = useState<number | null>(null);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return leads.filter((l) => {
      if (filter !== "all" && l.status !== filter) return false;
      if (!q) return true;
      return [l.name, l.email, l.phone, l.company, l.message].some((v) => v?.toLowerCase().includes(q));
    });
  }, [leads, filter, query]);

  async function updateStatus(id: number, status: LeadStatus) {
    setLeads((prev) => prev.map((l) => (l.id === id ? { ...l, status } : l)));
    await fetch(`/api/leads/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    router.refresh();
  }

  async function remove(id: number) {
    if (!confirm("Delete this lead permanently?")) return;
    setLeads((prev) => prev.filter((l) => l.id !== id));
    await fetch(`/api/leads/${id}`, { method: "DELETE" });
    router.refresh();
  }

  async function logout() {
    await fetch("/api/admin/login", { method: "DELETE" });
    router.refresh();
  }

  return (
    <div className="rounded-[32px] border border-slate-200 bg-white">
      <div className="flex flex-col gap-3 border-b border-slate-200 p-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-2">
          {(["all", ...LEAD_STATUSES] as const).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setFilter(s)}
              className={`rounded-full border px-3 py-1.5 text-xs font-bold capitalize transition ${filter === s ? "border-navy-600 bg-navy-600 text-white" : "border-slate-300 text-slate-700 hover:border-navy-300"}`}
            >
              {s}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search leads…"
            className="h-10 w-full rounded-full border border-slate-300 px-4 text-sm outline-none focus:border-navy-500 sm:w-56"
          />
          <button type="button" onClick={logout} className="h-10 whitespace-nowrap rounded-full border border-slate-300 px-4 text-xs font-bold text-slate-700 hover:border-brand-red hover:text-brand-red">
            Log out
          </button>
        </div>
      </div>

      {visible.length === 0 ? (
        <div className="p-12 text-center text-sm text-slate-500">No leads yet. Enquiries from the website will appear here.</div>
      ) : (
        <ul className="divide-y divide-slate-100">
          {visible.map((l) => {
            const open = expanded === l.id;
            return (
              <li key={l.id} className="p-5">
                <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                  <button type="button" onClick={() => setExpanded(open ? null : l.id)} className="flex min-w-0 flex-1 items-center gap-4 text-left">
                    <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-navy-600 text-sm font-bold text-white">{l.name[0]?.toUpperCase()}</span>
                    <div className="min-w-0">
                      <p className="truncate font-bold text-slate-900">
                        {l.name} {l.company && <span className="font-medium text-slate-500">· {l.company}</span>}
                      </p>
                      <p className="truncate text-xs text-slate-500">
                        {l.email}
                        {l.phone && ` · ${l.phone}`}
                        {l.serviceSlug && ` · ${serviceNames[l.serviceSlug] ?? l.serviceSlug}`}
                        {l.budget && ` · ${l.budget}`}
                      </p>
                    </div>
                  </button>
                  <div className="flex items-center gap-2 lg:shrink-0">
                    <span className="text-xs text-slate-400">{new Date(l.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</span>
                    <select
                      value={l.status}
                      onChange={(e) => updateStatus(l.id, e.target.value as LeadStatus)}
                      className={`h-9 rounded-full border px-3 text-xs font-bold capitalize outline-none ${statusStyles[l.status] ?? statusStyles.new}`}
                    >
                      {LEAD_STATUSES.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                    <button type="button" onClick={() => remove(l.id)} className="h-9 rounded-full border border-slate-200 px-3 text-xs font-bold text-slate-500 hover:border-brand-red hover:text-brand-red">
                      Delete
                    </button>
                  </div>
                </div>
                {open && (
                  <div className="mt-4 rounded-2xl bg-slate-50 p-4 text-sm leading-relaxed text-slate-700">
                    <p className="whitespace-pre-wrap">{l.message}</p>
                    <p className="mt-3 text-xs text-slate-400">Source: {l.source} · Lead #{l.id}</p>
                    <div className="mt-3 flex gap-2">
                      <a href={`mailto:${l.email}`} className="rounded-full bg-navy-600 px-3 py-1.5 text-xs font-bold text-white">Reply by email</a>
                      {l.phone && (
                        <a href={`https://wa.me/${l.phone.replace(/\D/g, "")}`} target="_blank" rel="noreferrer" className="rounded-full bg-emerald-500 px-3 py-1.5 text-xs font-bold text-white">
                          WhatsApp
                        </a>
                      )}
                    </div>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
