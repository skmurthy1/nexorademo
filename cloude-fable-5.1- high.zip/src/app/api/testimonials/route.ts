import { getTestimonials } from "@/lib/data";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const items = await getTestimonials();
  return NextResponse.json({ testimonials: items });
}
