import { db } from "@/db";
import { subscribers } from "@/db/schema";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { email?: string };
  const email = (body.email ?? "").trim().toLowerCase();
  if (!EMAIL_RE.test(email)) {
    return NextResponse.json({ error: "Please enter a valid email." }, { status: 400 });
  }
  const inserted = await db.insert(subscribers).values({ email }).onConflictDoNothing().returning();
  return NextResponse.json({
    ok: true,
    message: inserted.length ? "You're subscribed! 🎉" : "You're already on the list.",
  });
}
