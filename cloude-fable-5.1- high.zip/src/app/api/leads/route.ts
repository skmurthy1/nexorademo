import { db } from "@/db";
import { leads } from "@/db/schema";
import { isAdmin } from "@/lib/admin-auth";
import { getLeads } from "@/lib/data";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const str = (key: string, max = 500) => {
    const v = body[key];
    return typeof v === "string" ? v.trim().slice(0, max) : "";
  };

  const name = str("name", 160);
  const email = str("email", 200).toLowerCase();
  const message = str("message", 5000);

  if (name.length < 2) return NextResponse.json({ error: "Please enter your name." }, { status: 400 });
  if (!EMAIL_RE.test(email)) return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 });
  if (message.length < 10)
    return NextResponse.json({ error: "Please tell us a little more about your project (10+ characters)." }, { status: 400 });

  const [lead] = await db
    .insert(leads)
    .values({
      name,
      email,
      phone: str("phone", 40) || null,
      company: str("company", 160) || null,
      serviceSlug: str("serviceSlug", 160) || null,
      budget: str("budget", 60) || null,
      message,
      source: str("source", 60) || "website",
    })
    .returning();

  return NextResponse.json({ ok: true, id: lead.id }, { status: 201 });
}

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const rows = await getLeads();
  return NextResponse.json({ leads: rows });
}
