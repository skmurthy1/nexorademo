import { getCategories, getServices } from "@/lib/data";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const category = searchParams.get("category") ?? undefined;
  const [items, cats] = await Promise.all([getServices(category), getCategories()]);
  return NextResponse.json({ categories: cats, services: items });
}
