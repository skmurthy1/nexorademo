import Link from "next/link";
import type { Metadata } from "next";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { Reveal } from "@/components/reveal";
import { LogoMark } from "@/components/logo";
import { ArrowRight, Shield, Sparkles, Zap, Check } from "@/components/icons";

export const metadata: Metadata = {
  title: "About Us",
  description: "Nexora Softwares is a digital agency building modern websites, business software and marketing for growing Indian businesses.",
};

const values = [
  { icon: Zap, title: "Speed without shortcuts", body: "Modern tooling and reusable foundations let us ship in days — while keeping quality, security and performance high." },
  { icon: Shield, title: "Honest pricing", body: "Every price is published upfront. No hidden charges, no hourly meter running. You GET what you EXPECT." },
  { icon: Sparkles, title: "Built to grow", body: "Everything we deliver is yours to keep and scale — from a one-page site to a full business operating system." },
];

const stack = ["Next.js 16", "React 19", "TypeScript", "Tailwind CSS", "Node.js", "PostgreSQL", "Drizzle ORM", "Razorpay", "WhatsApp API", "Vercel / AWS"];

export default function AboutPage() {
  return (
    <>
      <Navbar />
      <main className="pt-32">
        <section className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div>
              <p className="text-sm font-bold uppercase tracking-[0.2em] text-navy-600">About Nexora</p>
              <h1 className="text-balance mt-3 text-4xl font-extrabold tracking-tight text-slate-950 sm:text-6xl">We make great software affordable for every business</h1>
              <p className="mt-5 text-lg leading-relaxed text-slate-600">
                Nexora Softwares started with a simple frustration: small businesses were quoted agency prices for basic websites, or handed
                slow templates that never brought customers. We set out to change that — pairing modern engineering with honest, upfront
                pricing so every shop, clinic, school and startup can look and operate like a leader.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href="/get-started" className="inline-flex h-12 items-center gap-2 rounded-full bg-navy-600 px-6 text-sm font-bold text-white transition hover:bg-navy-700">
                  Work with us <ArrowRight size={16} />
                </Link>
                <Link href="/services" className="inline-flex h-12 items-center gap-2 rounded-full border border-slate-300 px-6 text-sm font-bold text-slate-800 transition hover:border-navy-300">
                  See services
                </Link>
              </div>
            </div>
            <div className="relative mx-auto flex aspect-square w-full max-w-md items-center justify-center">
              <div className="brand-ring absolute inset-0 rounded-[48px] opacity-90 blur-2xl" />
              <div className="relative flex h-[82%] w-[82%] flex-col items-center justify-center rounded-[40px] bg-white shadow-2xl">
                <div className="animate-float">
                  <LogoMark size={140} />
                </div>
                <p className="mt-6 text-xl font-extrabold uppercase tracking-[0.15em] text-navy-600">Nexora Softwares</p>
                <p className="mt-1 text-sm font-semibold text-brand-red">You GET What You EXPECT</p>
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto mt-24 max-w-7xl px-5 sm:px-8">
          <div className="grid gap-6 md:grid-cols-3">
            {values.map((v, i) => (
              <Reveal key={v.title} delay={i * 80} className="rounded-3xl border border-slate-200 bg-white p-8">
                <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-navy-600 text-white"><v.icon size={22} /></span>
                <h3 className="mt-5 text-xl font-extrabold text-slate-950">{v.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-600">{v.body}</p>
              </Reveal>
            ))}
          </div>
        </section>

        <section className="mx-auto mt-24 max-w-7xl px-5 sm:px-8">
          <div className="grid gap-10 rounded-[40px] bg-slate-50 p-8 sm:p-12 lg:grid-cols-2">
            <div>
              <p className="text-sm font-bold uppercase tracking-[0.2em] text-navy-600">Our stack</p>
              <h2 className="text-balance mt-3 text-3xl font-extrabold tracking-tight text-slate-950 sm:text-4xl">Built on the latest, battle-tested technology</h2>
              <p className="mt-4 text-slate-600">
                We rebuilt our own website on this exact stack — server-rendered React with a PostgreSQL backend — so it loads instantly,
                ranks well and is simple to extend. Your project gets the same foundation.
              </p>
              <ul className="mt-6 space-y-2">
                {["Server-rendered pages for SEO & speed", "Type-safe backend with a real database", "Secure forms, role-based admin and APIs", "Deployable to any modern cloud"].map((t) => (
                  <li key={t} className="flex items-center gap-3 text-sm font-medium text-slate-800">
                    <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-brand-green text-white"><Check size={12} /></span>
                    {t}
                  </li>
                ))}
              </ul>
            </div>
            <div className="flex flex-wrap content-start gap-3">
              {stack.map((s) => (
                <span key={s} className="rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-800 shadow-sm">{s}</span>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
