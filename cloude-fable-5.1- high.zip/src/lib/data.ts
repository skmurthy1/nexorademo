import "server-only";
import { db } from "@/db";
import {
  categories,
  faqs,
  leads,
  services,
  testimonials,
  type Category,
  type Service,
} from "@/db/schema";
import { seedCategories, seedFaqs, seedTestimonials } from "@/db/seed-data";
import { asc, desc, eq, sql } from "drizzle-orm";

let seedPromise: Promise<void> | null = null;

export async function ensureSeeded() {
  if (!seedPromise) {
    seedPromise = (async () => {
      const [{ count }] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(categories);
      if (count > 0) return;

      for (const [cIndex, cat] of seedCategories.entries()) {
        const [inserted] = await db
          .insert(categories)
          .values({
            name: cat.name,
            slug: cat.slug,
            tagline: cat.tagline,
            description: cat.description,
            icon: cat.icon,
            accent: cat.accent,
            sortOrder: cIndex,
          })
          .onConflictDoNothing()
          .returning({ id: categories.id });
        if (!inserted) continue;
        await db.insert(services).values(
          cat.services.map((s, sIndex) => ({
            categoryId: inserted.id,
            name: s.name,
            slug: s.slug,
            shortDescription: s.shortDescription,
            description: s.description,
            priceMin: s.priceMin,
            priceMax: s.priceMax ?? null,
            originalPrice: s.originalPrice ?? null,
            priceNote: s.priceNote ?? null,
            features: s.features,
            deliveryDays: s.deliveryDays,
            badge: s.badge ?? null,
            popular: s.popular ?? false,
            sortOrder: sIndex,
          })),
        );
      }

      await db.insert(testimonials).values(
        seedTestimonials.map((t, i) => ({ ...t, rating: 5, featured: true, sortOrder: i })),
      );
      await db.insert(faqs).values(seedFaqs.map((f, i) => ({ ...f, sortOrder: i })));
    })().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

export type ServiceWithCategory = Service & { category: Category };

export async function getCategories() {
  await ensureSeeded();
  return db.select().from(categories).orderBy(asc(categories.sortOrder));
}

export async function getServices(categorySlug?: string): Promise<ServiceWithCategory[]> {
  await ensureSeeded();
  const rows = await db
    .select({ service: services, category: categories })
    .from(services)
    .innerJoin(categories, eq(services.categoryId, categories.id))
    .where(categorySlug ? eq(categories.slug, categorySlug) : undefined)
    .orderBy(asc(categories.sortOrder), asc(services.sortOrder));
  return rows.map((r) => ({ ...r.service, category: r.category }));
}

export async function getPopularServices(limit = 6): Promise<ServiceWithCategory[]> {
  await ensureSeeded();
  const rows = await db
    .select({ service: services, category: categories })
    .from(services)
    .innerJoin(categories, eq(services.categoryId, categories.id))
    .orderBy(desc(services.popular), asc(categories.sortOrder), asc(services.sortOrder))
    .limit(limit);
  return rows.map((r) => ({ ...r.service, category: r.category }));
}

export async function getServiceBySlug(slug: string): Promise<ServiceWithCategory | null> {
  await ensureSeeded();
  const [row] = await db
    .select({ service: services, category: categories })
    .from(services)
    .innerJoin(categories, eq(services.categoryId, categories.id))
    .where(eq(services.slug, slug))
    .limit(1);
  return row ? { ...row.service, category: row.category } : null;
}

export async function getTestimonials() {
  await ensureSeeded();
  return db
    .select()
    .from(testimonials)
    .where(eq(testimonials.featured, true))
    .orderBy(asc(testimonials.sortOrder));
}

export async function getFaqs() {
  await ensureSeeded();
  return db.select().from(faqs).orderBy(asc(faqs.sortOrder));
}

export async function getLeads() {
  return db.select().from(leads).orderBy(desc(leads.createdAt));
}

export async function getLeadStats() {
  const [row] = await db
    .select({
      total: sql<number>`count(*)::int`,
      newCount: sql<number>`count(*) filter (where ${leads.status} = 'new')::int`,
      contacted: sql<number>`count(*) filter (where ${leads.status} = 'contacted')::int`,
      won: sql<number>`count(*) filter (where ${leads.status} = 'won')::int`,
    })
    .from(leads);
  return row;
}


