export function formatINR(value: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value);
}

export function priceLabel(service: { priceMin: number; priceMax?: number | null }) {
  if (service.priceMax && service.priceMax !== service.priceMin) {
    return `${formatINR(service.priceMin)} – ${formatINR(service.priceMax)}`;
  }
  return formatINR(service.priceMin);
}

export const COMPANY = {
  name: "Nexora Softwares",
  tagline: "You GET What You EXPECT",
  domain: "www.nexorasoftwares.com",
  email: "hello@nexorasoftwares.com",
  phone: "+91 98765 43210",
  whatsapp: "919876543210",
  address: "Hyderabad, Telangana, India",
};

export const LEAD_STATUSES = ["new", "contacted", "quoted", "won", "lost"] as const;
export type LeadStatus = (typeof LEAD_STATUSES)[number];
