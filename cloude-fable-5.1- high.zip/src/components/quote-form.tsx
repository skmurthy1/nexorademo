"use client";

import { useState, type FormEvent } from "react";
import { ArrowRight, Check } from "./icons";

type ServiceOption = { slug: string; name: string; category: string };

const budgets = ["Under ₹5,000", "₹5,000 – ₹15,000", "₹15,000 – ₹50,000", "₹50,000+", "Not sure yet"];

export function QuoteForm({
  services,
  defaultService,
  defaultBrief,
  source = "website",
  compact = false,
}: {
  services: ServiceOption[];
  defaultService?: string;
  defaultBrief?: string;
  source?: string;
  compact?: boolean;
}) {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    serviceSlug: defaultService ?? "",
    budget: "",
    message: defaultBrief ?? "",
  });
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [error, setError] = useState("");

  const update = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setState("loading");
    setError("");
    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, source }),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(data.error ?? "Could not submit. Please try again.");
      setState("done");
    } catch (err) {
      setState("error");
      setError(err instanceof Error ? err.message : "Could not submit. Please try again.");
    }
  }

  if (state === "done") {
    return (
      <div className="rounded-3xl border border-emerald-200 bg-emerald-50 p-8 text-center">
        <span className="mx-auto inline-flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500 text-white">
          <Check size={28} />
        </span>
        <h3 className="mt-4 text-xl font-bold text-slate-900">Thanks, {form.name.split(" ")[0] || "there"}! 🎉</h3>
        <p className="mt-2 text-sm text-slate-600">
          We&apos;ve received your request and will reply within one working day with a detailed quote.
        </p>
      </div>
    );
  }

  const inputClass =
    "h-12 w-full rounded-2xl border border-slate-300 bg-white px-4 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-navy-500 focus:ring-4 focus:ring-navy-100";

  const grouped = services.reduce<Record<string, ServiceOption[]>>((acc, s) => {
    (acc[s.category] ||= []).push(s);
    return acc;
  }, {});

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className={`grid gap-4 ${compact ? "" : "sm:grid-cols-2"}`}>
        <div>
          <label className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-500">Your name *</label>
          <input required value={form.name} onChange={update("name")} placeholder="Full name" className={inputClass} />
        </div>
        <div>
          <label className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-500">Email *</label>
          <input required type="email" value={form.email} onChange={update("email")} placeholder="you@company.com" className={inputClass} />
        </div>
        <div>
          <label className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-500">Phone / WhatsApp</label>
          <input value={form.phone} onChange={update("phone")} placeholder="+91 98765 43210" className={inputClass} />
        </div>
        <div>
          <label className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-500">Business name</label>
          <input value={form.company} onChange={update("company")} placeholder="Your company" className={inputClass} />
        </div>
        <div>
          <label className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-500">Service</label>
          <select value={form.serviceSlug} onChange={update("serviceSlug")} className={inputClass}>
            <option value="">Not sure / multiple</option>
            {Object.entries(grouped).map(([cat, items]) => (
              <optgroup key={cat} label={cat}>
                {items.map((s) => (
                  <option key={s.slug} value={s.slug}>
                    {s.name}
                  </option>
                ))}
              </optgroup>
            ))}
          </select>
        </div>
        <div>
          <label className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-500">Budget</label>
          <select value={form.budget} onChange={update("budget")} className={inputClass}>
            <option value="">Select a range</option>
            {budgets.map((b) => (
              <option key={b} value={b}>
                {b}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div>
        <label className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-500">Tell us about your project *</label>
        <textarea
          required
          rows={5}
          value={form.message}
          onChange={update("message")}
          placeholder="What do you want to build? Who is it for? Any deadline?"
          className="w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-navy-500 focus:ring-4 focus:ring-navy-100"
        />
      </div>
      {error && <p className="text-sm font-medium text-brand-red">{error}</p>}
      <button
        type="submit"
        disabled={state === "loading"}
        className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-navy-600 px-6 text-sm font-semibold text-white shadow-lg shadow-navy-600/25 transition hover:bg-navy-700 disabled:opacity-60 sm:w-auto"
      >
        {state === "loading" ? "Sending…" : "Request free quote"} <ArrowRight size={16} />
      </button>
      <p className="text-xs text-slate-500">We reply within one working day. No spam, ever.</p>
    </form>
  );
}
