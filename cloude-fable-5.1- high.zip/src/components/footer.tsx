import Link from "next/link";
import { Logo } from "./logo";
import { Mail, MapPin, Phone, Whatsapp } from "./icons";
import { COMPANY } from "@/lib/format";
import { NewsletterForm } from "./newsletter-form";

const columns = [
  {
    title: "Services",
    links: [
      { label: "Website Design", href: "/services?category=website-design" },
      { label: "Software & CRM", href: "/services?category=software" },
      { label: "Digital Marketing", href: "/services?category=digital-marketing" },
      { label: "Brand Identity", href: "/services?category=brand-identity" },
    ],
  },
  {
    title: "Popular",
    links: [
      { label: "Business Website", href: "/services/business-website" },
      { label: "e-Commerce Website", href: "/services/ecommerce-website" },
      { label: "Workflow & CRM Software", href: "/services/workflow-crm-software" },
      { label: "Logo Design", href: "/services/logo-design" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About us", href: "/about" },
      { label: "Contact", href: "/contact" },
      { label: "Get a quote", href: "/get-started" },
      { label: "Client login", href: "/admin" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="relative mt-24 overflow-hidden border-t border-slate-200 bg-white">
      <div className="absolute inset-x-0 top-0 h-1 bg-[linear-gradient(90deg,#e63946_0_25%,#f9c80e_25%_50%,#2bb673_50%_75%,#1e6fdb_75%)]" />
      <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Logo />
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-slate-600">
              Modern websites, business software and digital marketing for growing Indian businesses —
              delivered fast, priced honestly.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li className="flex items-center gap-3">
                <Phone size={16} className="text-navy-600" /> {COMPANY.phone}
              </li>
              <li className="flex items-center gap-3">
                <Mail size={16} className="text-navy-600" /> {COMPANY.email}
              </li>
              <li className="flex items-center gap-3">
                <MapPin size={16} className="text-navy-600" /> {COMPANY.address}
              </li>
            </ul>
            <a
              href={`https://wa.me/${COMPANY.whatsapp}`}
              target="_blank"
              rel="noreferrer"
              className="mt-6 inline-flex items-center gap-2 rounded-full bg-emerald-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-emerald-600"
            >
              <Whatsapp size={16} /> Chat on WhatsApp
            </a>
          </div>
          {columns.map((col) => (
            <div key={col.title}>
              <h4 className="text-sm font-bold uppercase tracking-wider text-slate-900">{col.title}</h4>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.label}>
                    <Link href={l.href} className="text-sm text-slate-600 transition hover:text-navy-600">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-14 rounded-3xl border border-slate-200 bg-slate-50 p-6 sm:p-8 lg:flex lg:items-center lg:justify-between">
          <div>
            <h4 className="text-lg font-bold text-slate-900">Tips to grow your business online</h4>
            <p className="mt-1 text-sm text-slate-600">One short email a month. No spam, unsubscribe anytime.</p>
          </div>
          <NewsletterForm />
        </div>
        <div className="mt-10 flex flex-col items-start justify-between gap-4 border-t border-slate-200 pt-6 text-xs text-slate-500 sm:flex-row sm:items-center">
          <p>© {new Date().getFullYear()} {COMPANY.name}. All rights reserved.</p>
          <p className="font-semibold text-brand-red">{COMPANY.tagline}</p>
        </div>
      </div>
    </footer>
  );
}
