import type { ReactNode } from "react";

export function Marquee({
  children,
  reverse = false,
  vertical = false,
  duration = "40s",
  className = "",
  gap = "1.5rem",
}: {
  children: ReactNode;
  reverse?: boolean;
  vertical?: boolean;
  duration?: string;
  className?: string;
  gap?: string;
}) {
  const animation = vertical
    ? "animate-marquee-vertical"
    : reverse
      ? "animate-marquee-reverse"
      : "animate-marquee";
  return (
    <div
      className={`pause-on-hover flex overflow-hidden ${vertical ? "flex-col" : "flex-row"} ${className}`}
      style={{ gap, ["--gap" as string]: gap }}
    >
      {[0, 1].map((i) => (
        <div
          key={i}
          aria-hidden={i === 1}
          className={`flex shrink-0 ${vertical ? "flex-col" : "flex-row"} ${animation}`}
          style={{ gap, animationDuration: duration }}
        >
          {children}
        </div>
      ))}
    </div>
  );
}
