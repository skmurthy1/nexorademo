"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Logo } from "./logo";
import { ArrowRight, Menu, X } from "./icons";

const links = [
  { href: "/services", label: "Services" },
  { href: "/services?category=website-design", label: "Websites" },
  { href: "/services?category=software", label: "Software" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled || open
          ? "border-b border-slate-200/70 bg-white/85 shadow-[0_8px_30px_rgba(20,21,63,0.06)] backdrop-blur-xl"
          : "bg-transparent"
      }`}
    >
      <nav className="mx-auto flex h-[76px] max-w-7xl items-center justify-between px-5 sm:px-8">
        <Logo />
        <ul className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <li key={l.label}>
              <Link
                href={l.href}
                className="rounded-full px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-navy-50 hover:text-navy-700"
              >
                {l.label}
              </Link>
            </li>
          ))}
        </ul>
        <div className="hidden items-center gap-3 lg:flex">
          <Link
            href="/admin"
            className="rounded-full px-4 py-2 text-sm font-semibold text-slate-600 transition hover:text-navy-700"
          >
            Client login
          </Link>
          <Link
            href="/get-started"
            className="group inline-flex items-center gap-2 rounded-full bg-navy-600 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-navy-600/25 transition hover:bg-navy-700 hover:shadow-navy-700/30"
          >
            Get a free quote
            <ArrowRight size={16} className="transition-transform group-hover:translate-x-0.5" />
          </Link>
        </div>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-700 lg:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
        >
          {open ? <X /> : <Menu />}
        </button>
      </nav>
      {open && (
        <div className="border-t border-slate-200/70 bg-white px-5 pb-6 pt-3 lg:hidden">
          <ul className="flex flex-col">
            {links.map((l) => (
              <li key={l.label}>
                <Link
                  href={l.href}
                  className="block rounded-xl px-3 py-3 text-base font-semibold text-slate-800 hover:bg-navy-50"
                >
                  {l.label}
                </Link>
              </li>
            ))}
            <li>
              <Link href="/admin" className="block rounded-xl px-3 py-3 text-base font-semibold text-slate-800 hover:bg-navy-50">
                Client login
              </Link>
            </li>
          </ul>
          <Link
            href="/get-started"
            className="mt-3 flex items-center justify-center gap-2 rounded-full bg-navy-600 px-5 py-3 text-base font-semibold text-white"
          >
            Get a free quote <ArrowRight size={18} />
          </Link>
        </div>
      )}
    </header>
  );
}
