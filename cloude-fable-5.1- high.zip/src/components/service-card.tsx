import Link from "next/link";
import type { ServiceWithCategory } from "@/lib/data";
import { formatINR, priceLabel } from "@/lib/format";
import { ArrowRight, Clock, accentClasses, categoryIcon } from "./icons";

export function ServiceCard({ service }: { service: ServiceWithCategory }) {
  const accent = accentClasses[service.category.accent] ?? accentClasses.navy;
  const Icon = categoryIcon[service.category.icon] ?? categoryIcon.sparkles;
  return (
    <Link
      href={`/services/${service.slug}`}
      className="group relative flex h-full flex-col rounded-3xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:border-navy-200 hover:shadow-[0_24px_60px_-20px_rgba(45,46,143,0.3)]"
    >
      <div className="flex items-start justify-between">
        <span className={`inline-flex h-11 w-11 items-center justify-center rounded-2xl ${accent.soft} ${accent.text}`}>
          <Icon size={22} />
        </span>
        {service.badge && (
          <span className="rounded-full bg-brand-red/10 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide text-brand-red">
            {service.badge}
          </span>
        )}
      </div>
      <p className={`mt-5 text-xs font-bold uppercase tracking-wider ${accent.text}`}>{service.category.name}</p>
      <h3 className="mt-1.5 text-lg font-bold leading-snug text-slate-900">{service.name}</h3>
      <p className="mt-2 flex-1 text-sm leading-relaxed text-slate-600">{service.shortDescription}</p>
      <div className="mt-5 flex items-end justify-between border-t border-slate-100 pt-4">
        <div>
          {service.originalPrice && (
            <p className="text-xs text-slate-400 line-through">{formatINR(service.originalPrice)}</p>
          )}
          <p className="text-base font-extrabold text-slate-900">{priceLabel(service)}</p>
          <p className="mt-1 flex items-center gap-1 text-xs text-slate-500">
            <Clock size={13} /> {service.deliveryDays} day delivery
          </p>
        </div>
        <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 text-slate-700 transition group-hover:bg-navy-600 group-hover:text-white">
          <ArrowRight size={18} />
        </span>
      </div>
    </Link>
  );
}
