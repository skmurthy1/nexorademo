"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";
import { ArrowRight } from "./icons";

const examples = [
  "Build an e-commerce website for my saree boutique with UPI payments…",
  "I need a CRM for my 8-person real estate sales team…",
  "Design a logo, visiting card and brochure for my new clinic…",
  "Set up Google Business and Instagram for my restaurant…",
  "Create a school website with online admission forms…",
];

export function HeroPrompt() {
  const router = useRouter();
  const [value, setValue] = useState("");
  const [placeholder, setPlaceholder] = useState("");
  const [exampleIndex, setExampleIndex] = useState(0);

  useEffect(() => {
    const target = examples[exampleIndex];
    let i = 0;
    let timeout: ReturnType<typeof setTimeout>;
    const type = () => {
      setPlaceholder(target.slice(0, i));
      if (i < target.length) {
        i += 1;
        timeout = setTimeout(type, 28);
      } else {
        timeout = setTimeout(() => setExampleIndex((n) => (n + 1) % examples.length), 2200);
      }
    };
    type();
    return () => clearTimeout(timeout);
  }, [exampleIndex]);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const brief = value.trim() || examples[exampleIndex];
    router.push(`/get-started?brief=${encodeURIComponent(brief)}`);
  }

  return (
    <form
      onSubmit={onSubmit}
      className="group relative mx-auto mt-10 w-full max-w-2xl rounded-[28px] border border-slate-200 bg-white p-2 shadow-[0_20px_60px_-15px_rgba(45,46,143,0.25)] transition focus-within:border-navy-300 focus-within:shadow-[0_24px_70px_-15px_rgba(45,46,143,0.35)]"
    >
      <div className="absolute -inset-px -z-10 rounded-[29px] bg-[linear-gradient(120deg,#e63946,#f9c80e,#2bb673,#1e6fdb)] opacity-0 blur-md transition-opacity duration-500 group-focus-within:opacity-40" />
      <label htmlFor="brief" className="sr-only">
        Describe what you want to build
      </label>
      <textarea
        id="brief"
        rows={3}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder={placeholder || "Describe what you want to build…"}
        className="w-full resize-none rounded-[22px] bg-transparent px-5 pt-4 pb-2 text-base text-slate-900 outline-none placeholder:text-slate-400 sm:text-[17px]"
      />
      <div className="flex items-center justify-between gap-3 px-3 pb-2">
        <div className="hidden flex-wrap gap-2 sm:flex">
          {["Website", "CRM", "Branding", "Marketing"].map((chip) => (
            <button
              key={chip}
              type="button"
              onClick={() => setValue((v) => (v ? `${v} ${chip}` : `I need help with ${chip.toLowerCase()} for my business: `))}
              className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-semibold text-slate-600 transition hover:border-navy-200 hover:bg-navy-50 hover:text-navy-700"
            >
              {chip}
            </button>
          ))}
        </div>
        <button
          type="submit"
          className="ml-auto inline-flex h-11 items-center gap-2 rounded-full bg-navy-600 px-5 text-sm font-semibold text-white shadow-lg shadow-navy-600/25 transition hover:bg-navy-700"
        >
          Get free quote <ArrowRight size={16} />
        </button>
      </div>
    </form>
  );
}
