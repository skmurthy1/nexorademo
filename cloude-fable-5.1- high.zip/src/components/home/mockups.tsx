import { Check } from "../icons";

/* Chat-style "describe → we build" mockup */
export function ChatBuildMockup() {
  const steps = ["Understanding your business", "Designing pages & brand", "Building database & backend", "Testing on all devices", "Launching on your domain"];
  return (
    <div className="relative mx-auto w-full max-w-md">
      <div className="absolute -inset-6 -z-10 rounded-[40px] bg-[radial-gradient(ellipse_at_top,rgba(30,111,219,0.18),transparent_60%)]" />
      <div className="ml-auto w-[88%] rounded-3xl rounded-br-md bg-navy-600 px-5 py-4 text-sm text-white shadow-xl shadow-navy-600/30">
        Build an e-commerce website for my boutique with UPI payments and WhatsApp order alerts.
      </div>
      <div className="mt-4 w-[92%] rounded-3xl rounded-bl-md border border-slate-200 bg-white p-5 shadow-[0_20px_50px_-20px_rgba(20,21,63,0.3)]">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
          </span>
          <p className="text-xs font-bold uppercase tracking-wider text-slate-500">Nexora team is on it</p>
        </div>
        <ul className="mt-4 space-y-2.5">
          {steps.map((s, i) => (
            <li key={s} className="flex items-center gap-3 text-sm">
              <span
                className={`inline-flex h-5 w-5 items-center justify-center rounded-full ${
                  i < 3 ? "bg-emerald-500 text-white" : i === 3 ? "border-2 border-navy-400 border-t-transparent animate-spin" : "border-2 border-slate-200"
                }`}
              >
                {i < 3 && <Check size={12} />}
              </span>
              <span className={i < 3 ? "text-slate-800" : "text-slate-400"}>{s}</span>
            </li>
          ))}
        </ul>
        <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-slate-100">
          <div className="h-full w-[68%] rounded-full bg-[linear-gradient(90deg,#1e6fdb,#2bb673)]" />
        </div>
      </div>
    </div>
  );
}

/* Analytics dashboard mockup (like Hercules "Publish in a click") */
export function DashboardMockup() {
  const bars = [38, 52, 46, 64, 58, 78, 92];
  const months = ["Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar"];
  const kpis = [
    { label: "Visitors", value: "12.4k", delta: "+38%" },
    { label: "Enquiries", value: "318", delta: "+22%" },
    { label: "Orders", value: "1,204", delta: "+16%" },
    { label: "Revenue", value: "₹8.6L", delta: "+31%" },
  ];
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-[0_20px_50px_-24px_rgba(20,21,63,0.35)]">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-brand-red/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-brand-yellow/80" />
          <span className="h-2.5 w-2.5 rounded-full bg-brand-green/80" />
        </div>
        <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-600">● Live</span>
      </div>
      <div className="mt-3 grid grid-cols-4 gap-2">
        {kpis.map((k) => (
          <div key={k.label} className="rounded-xl bg-slate-50 p-2.5">
            <p className="text-[10px] font-semibold text-slate-500">{k.label}</p>
            <p className="mt-0.5 text-sm font-extrabold text-slate-900">{k.value}</p>
            <p className="text-[10px] font-bold text-emerald-600">{k.delta}</p>
          </div>
        ))}
      </div>
      <div className="mt-3 flex h-28 items-end gap-2 px-1">
        {bars.map((h, i) => (
          <div key={i} className="flex flex-1 flex-col items-center gap-1">
            <div
              className="w-full rounded-t-md bg-[linear-gradient(180deg,#3e49b8,#2d2e8f)] transition-all"
              style={{ height: `${h}%`, opacity: 0.55 + i * 0.065 }}
            />
            <span className="text-[9px] font-semibold text-slate-400">{months[i]}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* CRM pipeline mockup */
export function PipelineMockup() {
  const cols = [
    { name: "New leads", color: "bg-brand-blue", items: ["Sai Builders", "Zen Spa"] },
    { name: "Follow-up", color: "bg-brand-yellow", items: ["Royal Caterers", "Alpha Labs", "Max Fitness"] },
    { name: "Won", color: "bg-brand-green", items: ["Green Valley School"] },
  ];
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-[0_20px_50px_-24px_rgba(20,21,63,0.35)]">
      <div className="grid grid-cols-3 gap-2">
        {cols.map((c) => (
          <div key={c.name} className="rounded-xl bg-slate-50 p-2">
            <div className="flex items-center gap-1.5">
              <span className={`h-2 w-2 rounded-full ${c.color}`} />
              <p className="text-[10px] font-bold text-slate-600">{c.name}</p>
            </div>
            <div className="mt-2 space-y-1.5">
              {c.items.map((it) => (
                <div key={it} className="rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-[10px] font-semibold text-slate-800 shadow-sm">
                  {it}
                  <div className="mt-1 h-1 w-2/3 rounded-full bg-slate-100" />
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* Users & roles mockup */
export function RolesMockup() {
  const users = [
    { n: "Anita Rao", r: "Admin", c: "bg-navy-600" },
    { n: "Suresh K", r: "Sales", c: "bg-brand-blue" },
    { n: "Meena J", r: "Viewer", c: "bg-brand-green" },
  ];
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-[0_20px_50px_-24px_rgba(20,21,63,0.35)]">
      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Users & roles</p>
      <ul className="mt-2 divide-y divide-slate-100">
        {users.map((u) => (
          <li key={u.n} className="flex items-center justify-between py-2">
            <div className="flex items-center gap-2">
              <span className={`inline-flex h-7 w-7 items-center justify-center rounded-full ${u.c} text-[10px] font-bold text-white`}>{u.n[0]}</span>
              <span className="text-xs font-semibold text-slate-800">{u.n}</span>
            </div>
            <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-600">{u.r}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* Google local search mockup */
export function SearchMockup() {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-[0_20px_50px_-24px_rgba(20,21,63,0.35)]">
      <div className="flex items-center gap-2 rounded-full border border-slate-200 px-3 py-2 text-xs text-slate-500">
        <span className="font-bold text-brand-blue">G</span> best interior designer near me
      </div>
      <div className="mt-3 rounded-xl border border-emerald-200 bg-emerald-50/60 p-3">
        <div className="flex items-center justify-between">
          <p className="text-xs font-bold text-slate-900">Your Business</p>
          <span className="rounded-full bg-brand-yellow px-2 py-0.5 text-[10px] font-extrabold text-navy-900">#1</span>
        </div>
        <p className="mt-0.5 text-[10px] text-amber-500">★★★★★ <span className="text-slate-500">4.9 (212 reviews)</span></p>
        <p className="mt-1 text-[10px] text-slate-500">Open · Hyderabad · Call · Directions</p>
      </div>
      {[1, 2].map((i) => (
        <div key={i} className="mt-2 rounded-xl bg-slate-50 p-3">
          <div className="h-2 w-1/2 rounded bg-slate-200" />
          <div className="mt-1.5 h-2 w-3/4 rounded bg-slate-100" />
        </div>
      ))}
    </div>
  );
}
