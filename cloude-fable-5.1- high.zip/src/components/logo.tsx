import Link from "next/link";

export function LogoMark({ size = 44 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      {/* Multi-colour rounded frame: top-left red, top-right yellow, bottom-right green, bottom-left blue */}
      <path
        d="M50 8 H26 C16 8 8 16 8 26 V50"
        stroke="#E63946"
        strokeWidth="11"
        strokeLinecap="butt"
      />
      <path
        d="M50 8 H74 C84 8 92 16 92 26 V50"
        stroke="#F9C80E"
        strokeWidth="11"
        strokeLinecap="butt"
      />
      <path
        d="M92 50 V74 C92 84 84 92 74 92 H50"
        stroke="#2BB673"
        strokeWidth="11"
        strokeLinecap="butt"
      />
      <path
        d="M50 92 H26 C16 92 8 84 8 74 V50"
        stroke="#1E6FDB"
        strokeWidth="11"
        strokeLinecap="butt"
      />
      {/* Inner white tile */}
      <rect x="18" y="18" width="64" height="64" rx="12" fill="#ffffff" />
      {/* Navy N */}
      <path
        d="M31 70 V32 L37 32 L61 59 V48 H69 V70 H63 L39 43 V70 Z"
        fill="#2D2E8F"
      />
      {/* Red arrow (growth) */}
      <path d="M52 30 L71 30 L71 47 L65 41 L56 50 L50 44 L59 35 Z" fill="#E63946" />
    </svg>
  );
}

export function Logo({
  variant = "full",
  dark = false,
  className = "",
}: {
  variant?: "full" | "compact";
  dark?: boolean;
  className?: string;
}) {
  return (
    <Link href="/" className={`group inline-flex items-center gap-3 ${className}`} aria-label="Nexora Softwares home">
      <span className="transition-transform duration-300 group-hover:rotate-[-4deg] group-hover:scale-105">
        <LogoMark size={variant === "full" ? 46 : 36} />
      </span>
      <span className="flex flex-col leading-none">
        <span
          className={`text-[15px] font-extrabold uppercase tracking-[0.12em] ${dark ? "text-white" : "text-navy-600"}`}
        >
          Nexora
        </span>
        <span
          className={`text-[15px] font-extrabold uppercase tracking-[0.12em] ${dark ? "text-white" : "text-navy-600"}`}
        >
          Softwares
        </span>
        {variant === "full" && (
          <span className="mt-1 text-[9px] font-semibold tracking-wide text-brand-red">
            You <span className="font-extrabold">GET</span> What You <span className="font-extrabold">EXPECT</span>
          </span>
        )}
      </span>
    </Link>
  );
}
