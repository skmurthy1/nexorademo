"use client";

import { useState, type FormEvent } from "react";

export function NewsletterForm() {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState("");

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setState("loading");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = (await res.json()) as { message?: string; error?: string };
      if (!res.ok) throw new Error(data.error ?? "Something went wrong");
      setState("done");
      setMessage(data.message ?? "You're subscribed!");
      setEmail("");
    } catch (err) {
      setState("error");
      setMessage(err instanceof Error ? err.message : "Something went wrong");
    }
  }

  return (
    <form onSubmit={onSubmit} className="mt-4 flex w-full max-w-md flex-col gap-2 sm:flex-row lg:mt-0">
      <input
        type="email"
        required
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="you@company.com"
        className="h-12 flex-1 rounded-full border border-slate-300 bg-white px-5 text-sm outline-none transition focus:border-navy-500 focus:ring-4 focus:ring-navy-100"
      />
      <button
        type="submit"
        disabled={state === "loading"}
        className="h-12 rounded-full bg-navy-600 px-6 text-sm font-semibold text-white transition hover:bg-navy-700 disabled:opacity-60"
      >
        {state === "loading" ? "Joining…" : "Subscribe"}
      </button>
      {message && (
        <p className={`text-xs sm:absolute sm:mt-14 ${state === "error" ? "text-brand-red" : "text-emerald-600"}`}>{message}</p>
      )}
    </form>
  );
}
