export type SeedService = {
  name: string;
  slug: string;
  shortDescription: string;
  description: string;
  priceMin: number;
  priceMax?: number;
  originalPrice?: number;
  priceNote?: string;
  features: string[];
  deliveryDays: number;
  badge?: string;
  popular?: boolean;
};

export type SeedCategory = {
  name: string;
  slug: string;
  tagline: string;
  description: string;
  icon: string;
  accent: string;
  services: SeedService[];
};

const websiteFeatures = (pages: string) => [
  `${pages} custom-designed pages`,
  "Mobile-first responsive layout",
  "SEO-ready structure & meta tags",
  "Contact / enquiry forms",
  "Free SSL & hosting setup guidance",
  "WhatsApp & social media integration",
  "30 days post-launch support",
];

const websiteTypes: Array<[string, string, string]> = [
  ["Business Website", "business-website", "A professional online presence that turns visitors into enquiries."],
  ["e-Commerce Website", "ecommerce-website", "Sell online with cart, payments, shipping and order management."],
  ["Portfolio Website", "portfolio-website", "Showcase your work with a stunning, image-led portfolio."],
  ["One-Page Website", "one-page-website", "A focused, fast single-page site perfect for launches and campaigns."],
  ["Educational Website", "educational-website", "Courses, admissions, faculty and notices in one organised site."],
  ["News & Magazine Website", "news-magazine-website", "High-volume publishing with categories, tags and ad slots."],
  ["Membership Website", "membership-website", "Gated content, subscriptions and member dashboards."],
  ["Directory Website", "directory-website", "Searchable listings with filters, maps and claimable profiles."],
  ["Forum Website", "forum-website", "Community discussions with moderation and user profiles."],
  ["Web Portal", "web-portal", "Role-based portals for customers, vendors, students or employees."],
  ["Blog Website", "blog-website", "Content-first design built for readability and discovery."],
  ["Non-Profit Website", "non-profit-website", "Tell your story, accept donations and recruit volunteers."],
  ["Celebrity Website", "celebrity-website", "Fan-focused sites with media galleries, events and press kits."],
];

export const seedCategories: SeedCategory[] = [
  {
    name: "Website Design",
    slug: "website-design",
    tagline: "Websites that work as hard as you do",
    description:
      "From one-page launches to full e-commerce stores, we design and build fast, mobile-first websites on modern stacks.",
    icon: "globe",
    accent: "blue",
    services: websiteTypes.map(([name, slug, short], index) => {
      const isEcom = slug === "ecommerce-website";
      return {
        name,
        slug,
        shortDescription: short,
        description: `${short} Every ${name.toLowerCase()} we ship is built on a modern, secure stack, optimised for Google and designed to look great on every screen. Choose the Basic plan for a lean launch or Standard for more pages and features.`,
        priceMin: isEcom ? 20000 : 5000,
        priceMax: isEcom ? 30000 : 10000,
        priceNote: isEcom ? "Basic (1-25 products) · Standard (1-50 products)" : "Basic (1-5 pages) · Standard (5-10 pages)",
        features: isEcom
          ? [
              "Product catalogue up to 50 products",
              "Secure payment gateway (Razorpay / UPI / Cards)",
              "Cart, checkout & order tracking",
              "Coupons, shipping rules & GST invoices",
              "Mobile-first responsive design",
              "SEO-ready & analytics integrated",
              "45 days post-launch support",
            ]
          : websiteFeatures(isEcom ? "Up to 50" : "5-10"),
        deliveryDays: isEcom ? 21 : 10,
        badge: index < 3 ? "Popular" : undefined,
        popular: index < 2,
      };
    }),
  },
  {
    name: "Software & CRM",
    slug: "software",
    tagline: "Run your business from one dashboard",
    description:
      "Custom workflow, CRM and automation software built for small and growing businesses — no bloated enterprise pricing.",
    icon: "cpu",
    accent: "navy",
    services: [
      {
        name: "Workflow Management & CRM Software",
        slug: "workflow-crm-software",
        shortDescription: "Track leads, deals, tasks and follow-ups for your whole team in one place.",
        description:
          "A ready-to-deploy CRM and workflow system tailored to your sales process. Manage contacts, pipelines, tasks, reminders and reports — with role-based access for your team. Includes onboarding and data import.",
        priceMin: 2000,
        originalPrice: 25000,
        priceNote: "Launch offer · 92% off for a limited time",
        features: [
          "Contacts, accounts & deal pipeline",
          "Task management & automated follow-up reminders",
          "Roles & permissions for team members",
          "Reports & dashboards",
          "WhatsApp / email notifications",
          "Data import from Excel",
          "Cloud hosted with daily backups",
        ],
        deliveryDays: 7,
        badge: "92% OFF",
        popular: true,
      },
      {
        name: "Custom Business Software",
        slug: "custom-business-software",
        shortDescription: "Billing, inventory, HR or any internal tool — built exactly for your workflow.",
        description:
          "Describe how your business runs and we will build the software around it: billing & invoicing, inventory, attendance, school management, bookings and more. Delivered as a secure web app with a modern database backend.",
        priceMin: 15000,
        priceNote: "Starting price · final quote after discovery call",
        features: [
          "Requirement discovery workshop",
          "Custom modules & workflows",
          "Secure authentication & user roles",
          "Admin dashboard & analytics",
          "API integrations (payments, SMS, maps)",
          "Training & documentation",
          "Ongoing maintenance plans available",
        ],
        deliveryDays: 30,
      },
      {
        name: "Mobile App Development",
        slug: "mobile-app-development",
        shortDescription: "Android & iOS apps that connect to your website or software.",
        description:
          "Cross-platform mobile apps for customers or staff — with push notifications, offline support and Play Store / App Store publishing included.",
        priceMin: 25000,
        priceNote: "Starting price",
        features: [
          "Android & iOS from one codebase",
          "Push notifications",
          "Secure login & user profiles",
          "Store listing & publishing",
          "Backend & admin panel",
          "Analytics & crash reporting",
        ],
        deliveryDays: 45,
      },
    ],
  },
  {
    name: "Digital Marketing",
    slug: "digital-marketing",
    tagline: "Get found. Get customers.",
    description:
      "Google Business, social media, promo videos and complete online solutions that put your business in front of local customers.",
    icon: "megaphone",
    accent: "red",
    services: [
      {
        name: "Complete Business Online Solutions",
        slug: "complete-business-online-solutions",
        shortDescription: "Everything a local business needs online, managed for you month after month.",
        description:
          "A bundled plan covering Google Business Profile, social media posting, poster designs, festival wishes and performance reporting. Pick 3 months to test or 1 year for the best value.",
        priceMin: 3999,
        priceMax: 9999,
        priceNote: "3 Months · 1 Year",
        features: [
          "Google Business Profile setup & optimisation",
          "Social media account setup (Instagram, Facebook)",
          "Monthly poster & creative designs",
          "Festival & calendar wishes",
          "Review management",
          "Monthly performance report",
        ],
        deliveryDays: 5,
        badge: "Best Value",
        popular: true,
      },
      {
        name: "Google My Business (GMB) Setup",
        slug: "gmb-account-creation",
        shortDescription: "Appear on Google Maps & local search with a verified, optimised profile.",
        description:
          "We create, verify and fully optimise your Google Business Profile with categories, services, photos, posts and a review strategy so local customers find you first.",
        priceMin: 2500,
        features: ["Profile creation & verification", "Category & service optimisation", "Photos & cover design", "Review link & QR code", "First 4 Google posts"],
        deliveryDays: 3,
      },
      {
        name: "Social Media Business (SMB) Setup",
        slug: "smb-account-setup",
        shortDescription: "Professional Instagram, Facebook & LinkedIn business pages ready to grow.",
        description:
          "Branded profile setup across major platforms with bios, highlights, cover art and the first set of posts — plus a content calendar to get you started.",
        priceMin: 4000,
        features: ["Instagram, Facebook & LinkedIn pages", "Branded covers & highlight icons", "First 6 posts designed", "Content calendar template", "Meta Business Suite setup"],
        deliveryDays: 4,
      },
      {
        name: "YouTube Channel Creation",
        slug: "youtube-channel-creation",
        shortDescription: "Branded channel with art, intro template and SEO-friendly setup.",
        description:
          "Launch your YouTube presence with professional channel art, an intro/outro template, playlists and optimised about section.",
        priceMin: 1000,
        features: ["Channel art & logo", "Intro / outro template", "Playlist structure", "Channel SEO & keywords"],
        deliveryDays: 2,
      },
      {
        name: "Digital Promo Videos",
        slug: "digital-promo-videos",
        shortDescription: "30 or 60-second promo videos in FHD / 4K for ads and social media.",
        description:
          "Scroll-stopping promo videos with motion graphics, voice-over and music, delivered in vertical and horizontal formats.",
        priceMin: 800,
        priceMax: 1500,
        priceNote: "30 Sec · 60 Sec · FHD / 4K",
        features: ["Script & storyboard", "Motion graphics & stock footage", "Voice-over & music", "Vertical + horizontal exports"],
        deliveryDays: 4,
      },
      {
        name: "Digital Visiting Card",
        slug: "digital-visiting-card",
        shortDescription: "A shareable mobile card with one-tap call, WhatsApp, map and payments.",
        description:
          "A modern replacement for paper cards: a mobile-friendly page with your contact buttons, gallery, services and vCard download — shareable by link or QR.",
        priceMin: 1000,
        features: ["One-tap call / WhatsApp / email", "Save-to-contacts vCard", "Gallery & services", "QR code for print", "1 year hosting included"],
        deliveryDays: 2,
      },
      {
        name: "Poster Design",
        slug: "poster-design",
        shortDescription: "Eye-catching posters for social media, print and events.",
        description: "Custom poster creatives sized for Instagram, WhatsApp status, print or hoardings.",
        priceMin: 500,
        priceNote: "Per design",
        features: ["Custom design", "Print & social sizes", "2 revisions", "Source files on request"],
        deliveryDays: 1,
      },
      {
        name: "Calendar Wishes Pack",
        slug: "calendar-wishes",
        shortDescription: "A full year of branded festival & occasion wishes for your social media.",
        description:
          "Stay top-of-mind all year with branded greetings for every major festival, national day and occasion — delivered as a ready-to-post pack.",
        priceMin: 5000,
        priceNote: "Full year pack",
        features: ["40+ branded creatives", "All major Indian festivals", "Instagram, status & print sizes", "Delivered as monthly packs"],
        deliveryDays: 7,
      },
    ],
  },
  {
    name: "Brand Identity",
    slug: "brand-identity",
    tagline: "Look as good as you are",
    description:
      "Logos, visiting cards, brochures and company profiles that give your business a consistent, professional identity.",
    icon: "palette",
    accent: "yellow",
    services: [
      {
        name: "Logo Design",
        slug: "logo-design",
        shortDescription: "A memorable logo with full brand files for print and digital.",
        description:
          "We craft 3 unique logo concepts, refine your favourite and deliver a complete kit: colour, mono, favicon, social avatars and a mini brand guide.",
        priceMin: 3000,
        features: ["3 initial concepts", "Unlimited revisions on chosen concept", "Vector, PNG, SVG & PDF files", "Colour palette & font guide", "Social media avatars"],
        deliveryDays: 5,
        badge: "Popular",
        popular: true,
      },
      {
        name: "Company Profile Creation",
        slug: "company-profile-creation",
        shortDescription: "A polished PDF profile that wins tenders, clients and partners.",
        description:
          "A professionally written and designed company profile covering your story, services, team, clients and achievements — print and digital ready.",
        priceMin: 5000,
        features: ["Copywriting included", "8-16 designed pages", "Print-ready PDF", "Editable source files"],
        deliveryDays: 7,
      },
      {
        name: "Visiting Card Design",
        slug: "visiting-card-design",
        shortDescription: "Premium double-sided visiting card designs, print-ready.",
        description: "Elegant, on-brand visiting cards with QR code and print specifications for any printer.",
        priceMin: 2000,
        features: ["Double-sided design", "QR code integration", "Print-ready CMYK files", "2 concepts"],
        deliveryDays: 2,
      },
      {
        name: "Brochure Design",
        slug: "brochure-design",
        shortDescription: "Bi-fold and tri-fold brochures that explain your offer beautifully.",
        description: "Brochures designed to be read — clear hierarchy, strong visuals and a call to action.",
        priceMin: 3000,
        features: ["Bi-fold or tri-fold", "Copy layout & iconography", "Print & digital versions", "2 revisions"],
        deliveryDays: 4,
      },
      {
        name: "Pamphlet Design",
        slug: "pamphlet-design",
        shortDescription: "High-impact flyers for offers, events and door-to-door campaigns.",
        description: "Single-sheet pamphlets designed to grab attention and drive a response.",
        priceMin: 3000,
        features: ["A4 / A5 sizes", "Front & back", "Print-ready files", "2 revisions"],
        deliveryDays: 3,
      },
      {
        name: "ID Card Design",
        slug: "id-card-design",
        shortDescription: "Professional employee & student ID card templates.",
        description: "Secure, branded ID card designs with photo, QR/barcode and lanyard-ready layout.",
        priceMin: 1000,
        features: ["Front & back design", "Photo & QR placeholders", "Print-ready template", "Bulk data merge support"],
        deliveryDays: 2,
      },
    ],
  },
];

export const seedTestimonials = [
  {
    name: "Ramesh Kumar",
    role: "Founder",
    company: "RK Interiors, Hyderabad",
    quote:
      "Other agencies quoted ₹60,000 for a basic website. Nexora built us a faster, better-looking site for a fraction of that — and enquiries started within a week.",
  },
  {
    name: "Priya Sharma",
    role: "Director",
    company: "Bright Minds Academy",
    quote:
      "The CRM software replaced three spreadsheets and a WhatsApp group. Our admissions team finally knows who to follow up with and when.",
  },
  {
    name: "Arjun Reddy",
    role: "Owner",
    company: "Reddy Pharma Distributors",
    quote:
      "GMB setup alone brought us 40+ calls in the first month. The team is responsive and actually delivers what they promise.",
  },
  {
    name: "Sneha Patil",
    role: "Co-founder",
    company: "Urban Bloom Florists",
    quote:
      "Our e-commerce store went live in under 3 weeks. Payments, shipping and GST invoices all worked on day one.",
  },
  {
    name: "Mohammed Irfan",
    role: "Proprietor",
    company: "Irfan Steel Works",
    quote:
      "Logo, visiting cards, brochure and company profile — one team, one consistent brand. We now look like the company we always were.",
  },
  {
    name: "Kavitha Nair",
    role: "Principal",
    company: "Green Valley School",
    quote:
      "The school website with admissions forms and notice board made parent communication effortless. Highly recommended.",
  },
  {
    name: "Vikram Singh",
    role: "Managing Partner",
    company: "VS Legal Associates",
    quote:
      "Professional, fast and transparent pricing. The digital visiting card is something every client comments on.",
  },
  {
    name: "Deepa Menon",
    role: "Founder",
    company: "Spice Route Caterers",
    quote:
      "The yearly online solutions plan keeps our social media alive without me lifting a finger. Festival posts are always on time.",
  },
];

export const seedFaqs = [
  {
    question: "How long does it take to build a website?",
    answer:
      "Most business websites go live within 7-10 working days after we receive your content. E-commerce stores and custom software typically take 3-6 weeks depending on scope.",
  },
  {
    question: "What technology do you use?",
    answer:
      "We build on modern, secure stacks — Next.js and React for the frontend, Node.js with PostgreSQL for backends, and cloud hosting with free SSL. Everything is mobile-first and SEO-ready.",
  },
  {
    question: "Do I own the website and code after delivery?",
    answer:
      "Yes. You receive full ownership of your domain, hosting, design and source code. We are happy to hand over or continue maintaining it for you.",
  },
  {
    question: "Are there hidden charges?",
    answer:
      "No. Prices listed are what you pay. Domain and hosting (if not already owned) are billed at actual cost, and we tell you upfront before any work begins.",
  },
  {
    question: "Can you redesign my existing website or software?",
    answer:
      "Absolutely. We regularly migrate old WordPress, Wix or PHP sites to modern, faster stacks without losing SEO rankings, and modernise legacy software.",
  },
  {
    question: "What support do I get after launch?",
    answer:
      "Every project includes 30-45 days of free post-launch support. After that, affordable monthly maintenance plans cover updates, backups, security and small changes.",
  },
  {
    question: "How do payments work?",
    answer:
      "50% advance to start and 50% on delivery for most projects. We accept UPI, bank transfer and all major cards. GST invoices are provided.",
  },
];
